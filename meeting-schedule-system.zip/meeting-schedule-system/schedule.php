<?php
include("auth.php");
include("db.php");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $faculty_id = $_POST['faculty_id'];
    $room_id = $_POST['room_id'];
    $date = $_POST['date'];
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];
    $created_by = $_SESSION['email'];

    // Check for room or faculty conflict
    $conflict = mysqli_query($conn, "
        SELECT * FROM meetings 
        WHERE meeting_date = '$date' 
        AND (
            (room_id = '$room_id') OR 
            (faculty_id = '$faculty_id')
        ) 
        AND (
            (start_time < '$end' AND end_time > '$start')
        )
    ");

    if (mysqli_num_rows($conflict) > 0) {
        $error = "Time slot is already booked for this room or teacher.";
    } else {
        mysqli_query($conn, "INSERT INTO meetings (faculty_id, room_id, meeting_date, start_time, end_time, created_by)
            VALUES ('$faculty_id', '$room_id', '$date', '$start', '$end', '$created_by')");
        $success = "Meeting scheduled successfully!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Schedule Meeting</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Top Navigation Bar -->
<nav class="top-nav">
    <div class="nav-logo">Meeting Schedule System</div>
    <ul class="nav-links">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="schedule.php">Schedule Meeting</a></li>
        <li><a href="view_meetings.php">View Meetings</a></li>
        <li><a href="faculty_list.php">View Faculty</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

        <div class="main">
            <h2>Schedule a Meeting</h2>

            <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
            <?php if (!empty($success)) echo "<p style='color:green;'>$success</p>"; ?>

            <form method="POST">
                <label>Faculty:</label>
                <select name="faculty_id" required>
                    <option value="">Select</option>
                    <?php
                    $faculty = mysqli_query($conn, "SELECT * FROM faculty");
                    while ($f = mysqli_fetch_assoc($faculty)) {
                        echo "<option value='{$f['id']}'>{$f['name']} ({$f['designation']})</option>";
                    }
                    ?>
                </select><br><br>

                <label>Room:</label>
                <select name="room_id" required>
                    <option value="">Select</option>
                    <?php
                    $rooms = mysqli_query($conn, "SELECT * FROM rooms");
                    while ($r = mysqli_fetch_assoc($rooms)) {
                        echo "<option value='{$r['id']}'>{$r['room_name']}</option>";
                    }
                    ?>
                </select><br><br>

                <label>Date:</label>
                <input type="date" name="date" required><br><br>

                <label>Start Time:</label>
                <input type="time" name="start_time" required><br><br>

                <label>End Time:</label>
                <input type="time" name="end_time" required><br><br>

                <button type="submit">Schedule</button>
            </form>
        </div>
    </div>
</body>
</html>
