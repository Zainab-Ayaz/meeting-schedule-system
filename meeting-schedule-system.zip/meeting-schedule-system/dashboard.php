<?php include("auth.php"); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Meeting Schedule System</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f3eaff;
        }

        .container {
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #7b2cbf;
            color: white;
            padding: 20px;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            margin: 10px 0;
            padding: 10px;
            background-color: #9d4edd;
            border-radius: 5px;
            text-align: center;
        }

        .sidebar a:hover {
            background-color: #c77dff;
        }

        .main-content {
            flex-grow: 1;
            padding: 20px;
            overflow-y: auto;
        }

        #calendar {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="container">
    <div class="sidebar">
        <h2>Meeting Portal</h2>
        <a href="schedule.php">📅 Schedule Meeting</a>
        <a href="view_meetings.php">📋 View Meetings</a>
        <a href="faculty_list.php">👩‍🏫 View Faculty</a>
        <a href="logout.php">🚪 Logout</a>
    </div>
    <div class="main-content">
        <h2>Welcome, <?= $_SESSION['email'] ?></h2>
        <p>Below is your university meeting calendar:</p>
        <div id="calendar"></div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                start: 'title',
                center: '',
                end: 'today prev,next'
            }
        });
        calendar.render();
    });
</script>
</body>
</html>
