<?php
include("auth.php");
include("db.php");

$query = "SELECT name, designation FROM faculty ORDER BY name";
$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Faculty List - Meeting Schedule System</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <nav class="top-nav">
    <div class="nav-logo">Meeting Schedule System</div>
    <ul class="nav-links">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="schedule.php">Schedule Meeting</a></li>
        <li><a href="view_meetings.php">View Meetings</a></li>
        <li><a href="faculty_list.php">View Faculty</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

    <div class="container">
        <h1>Faculty List</h1>
        <?php if (mysqli_num_rows($result) > 0): ?>
            <ul>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <li><?= htmlspecialchars($row['name']) ?> (<?= htmlspecialchars($row['designation']) ?>)</li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No faculty found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
