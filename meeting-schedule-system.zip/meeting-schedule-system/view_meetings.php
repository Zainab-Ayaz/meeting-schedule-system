<?php
include("auth.php");
include("db.php");

// Query to fetch meetings with faculty and room details
$query = "
    SELECT meetings.id, faculty.name AS faculty_name, faculty.designation, rooms.room_name, 
           meetings.meeting_date, meetings.start_time, meetings.end_time
    FROM meetings
    JOIN faculty ON meetings.faculty_id = faculty.id
    JOIN rooms ON meetings.room_id = rooms.id
    ORDER BY meetings.meeting_date, meetings.start_time
";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>View Meetings - Meeting Schedule System</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
        /* Page container */
        .container {
            max-width: 900px;
            margin: 30px auto;
            padding: 0 15px;
        }
        h1 {
            color: #6a0dad;
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        thead {
            background-color: #6a0dad;
            color: white;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        tbody tr:hover {
            background-color: #f3e8ff;
        }
        /* Responsive */
        @media(max-width: 600px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }
            thead tr {
                display: none;
            }
            tbody tr {
                margin-bottom: 15px;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                padding: 10px;
            }
            tbody td {
                padding-left: 50%;
                position: relative;
                text-align: right;
                border-bottom: none;
            }
            tbody td::before {
                content: attr(data-label);
                position: absolute;
                left: 15px;
                top: 12px;
                font-weight: bold;
                text-align: left;
                color: #6a0dad;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="top-nav">
    <div class="nav-logo">Meeting Schedule System</div>
    <ul class="nav-links">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="schedule.php">Schedule Meeting</a></li>
        <li><a href="view_meetings.php">View Meetings</a></li>
        <li><a href="faculty_list.php">View Faculty</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>
    <div class="container">
        <h1>Scheduled Meetings</h1>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Faculty (Designation)</th>
                        <th>Room</th>
                        <th>Date</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td data-label="Faculty">
                                <?= htmlspecialchars($row['faculty_name']) ?> (<?= htmlspecialchars($row['designation']) ?>)
                            </td>
                            <td data-label="Room"><?= htmlspecialchars($row['room_name']) ?></td>
                            <td data-label="Date"><?= htmlspecialchars($row['meeting_date']) ?></td>
                            <td data-label="Time">
                                <?= htmlspecialchars($row['start_time']) ?> - <?= htmlspecialchars($row['end_time']) ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No meetings scheduled.</p>
        <?php endif; ?>

    </div>
</body>
</html>
