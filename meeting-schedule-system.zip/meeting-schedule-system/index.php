<!-- Function: Authenticates users using email and password. -->
<?php
session_start();
include("db.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $query = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' AND password='$pass'");
    if (mysqli_num_rows($query) == 1) {
        $_SESSION['email'] = $email;
        header("Location: dashboard.php");
    } else {
        $error = "Invalid credentials!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Meeting Schedule System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="login-page">
    <h1>Meeting Schedule System</h1>
    <form method="post">
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Login</button>
        <p class="error"><?php echo $error ?? ''; ?></p>
    </form>
</body>
</html>
